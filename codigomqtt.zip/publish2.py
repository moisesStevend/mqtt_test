#!/usr/bin/env python

import paho.mqtt.client as mqtt

client = mqtt.Client()
client.connect("test.mosquitto.org",1883,60)
client.publish("topic/test", "hola");
client.disconnect();


